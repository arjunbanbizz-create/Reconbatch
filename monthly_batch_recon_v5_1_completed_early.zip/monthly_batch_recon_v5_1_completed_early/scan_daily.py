from app import scan_daily_directory

results = scan_daily_directory()
errors = 0
for name, result, error in results:
    if error:
        errors += 1
        print(f'ERROR {name}: {error}')
    elif result.get('skipped'):
        print(f'SKIP  {name}: already imported')
    else:
        print(f'OK    {name}: {result["loaded"]} new, {result["updated"]} updated')
raise SystemExit(1 if errors else 0)
