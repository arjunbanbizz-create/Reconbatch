import ast
import csv
import io
import sqlite3
import sys
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import Mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from common_names import has_common_name, display_common_name


class CommonNameTests(unittest.TestCase):
    def test_real_common_name(self):
        self.assertTrue(has_common_name('GPA Burial', 'J05.01.BI-GPABU-MLY GPA BURRIAL'))
        self.assertEqual(display_common_name(' GPA Burial ', 'J05.01.BI-GPABU-MLY GPA BURRIAL'), 'GPA Burial')

    def test_legacy_fallback_detected(self):
        self.assertFalse(has_common_name('J05.01.BI-GPABU-MLY', 'j05.01.bi-gpabu-mly'))
        self.assertFalse(has_common_name(' ', 'OPCON_A'))
        self.assertEqual(display_common_name('OPCON_A', 'OPCON_A'), 'Common name not configured')

    def test_jinja_templates_compile(self):
        from jinja2 import Environment
        env = Environment()
        for p in (ROOT / 'templates').glob('*.html'):
            env.parse(p.read_text(encoding='utf-8'))

    def test_effective_month_name_change_preserves_prior_and_future_versions(self):
        source = ast.parse((ROOT / 'app.py').read_text())
        node = next(n for n in source.body if isinstance(n, ast.FunctionDef) and n.name == 'update_common_name_effective')
        conn = sqlite3.connect(':memory:')
        conn.row_factory = sqlite3.Row
        conn.executescript("""
            CREATE TABLE BatchMaster(batch_version_id INTEGER PRIMARY KEY, batch_key TEXT,
                schedulename TEXT, jobname TEXT, jobid TEXT, commonname TEXT,
                frequency TEXT, weeks TEXT, effective_from TEXT, effective_to TEXT);
            INSERT INTO BatchMaster VALUES(1,'a','APP005','OPCON_A','BI-MLY','OPCON_A','Monthly','3','2026-01','2026-12');
            INSERT INTO BatchMaster VALUES(2,'a','APP005','OPCON_A','BI-MLY','Future name','Monthly','3','2027-01',NULL);
        """)
        def change(c, version, values, month):
            c.execute('UPDATE BatchMaster SET effective_to=? WHERE batch_version_id=?', ('2026-10', version))
            c.execute('INSERT INTO BatchMaster VALUES(3,?,?,?,?,?,?,?,?,?)',
                ('a','APP005','OPCON_A','BI-MLY',values['commonname'],'Monthly','3',month,None))
        ns = dict(validate_month_key=lambda x: x,
                  clean_text=lambda x,*a,**k: x.strip(),
                  has_common_name=has_common_name,
                  update_batch_effective=change,
                  previous_month_key=lambda x: '2026-12')
        exec(compile(ast.Module(body=[node], type_ignores=[]), '<update_name>', 'exec'), ns)
        old = conn.execute('SELECT * FROM BatchMaster WHERE batch_version_id=1').fetchone()
        self.assertTrue(ns['update_common_name_effective'](conn, old, 'GPA Burial', '2026-11'))
        rows = conn.execute('SELECT effective_from,effective_to,commonname FROM BatchMaster ORDER BY effective_from').fetchall()
        self.assertEqual([tuple(r) for r in rows], [
            ('2026-01','2026-10','OPCON_A'),
            ('2026-11','2026-12','GPA Burial'),
            ('2027-01',None,'Future name')])
        conn.close()

    def test_bulk_common_name_csv_validates_exact_matching_and_history(self):
        # Run the real import function against an isolated SQLite DB with
        # its write lock and update handler replaced by controlled test doubles.
        source = ast.parse((ROOT / 'app.py').read_text())
        names = {'import_common_names_csv_bytes'}
        nodes = [n for n in source.body if isinstance(n, ast.FunctionDef) and n.name in names]
        path = Path(tempfile.mkdtemp()) / 'test.db'
        conn = sqlite3.connect(path)
        conn.executescript('''
        CREATE TABLE BatchMaster (batch_version_id INTEGER PRIMARY KEY, batch_key TEXT,
            schedulename TEXT, jobname TEXT, jobid TEXT, commonname TEXT,
            frequency TEXT, weeks TEXT, effective_from TEXT, effective_to TEXT);
        CREATE TABLE DailyRun (id INTEGER PRIMARY KEY, status TEXT);
        INSERT INTO BatchMaster VALUES(1,'key1','APP005','OPCON_A','BI-MLY','OPCON_A','Monthly','3','2026-01',NULL);
        INSERT INTO DailyRun VALUES(1,'COMPLETED');
        ''')
        conn.commit(); conn.close()

        @contextmanager
        def no_lock():
            yield

        def get_db():
            c = sqlite3.connect(path)
            c.row_factory = sqlite3.Row
            return c

        def active_rows(c, y, m):
            ym = f'{y:04d}-{m:02d}'
            return c.execute('SELECT * FROM BatchMaster WHERE effective_from<=? AND (effective_to IS NULL OR effective_to>=?)', (ym, ym)).fetchall()

        def update_name(c, row, name, effective):
            c.execute('UPDATE BatchMaster SET commonname=? WHERE batch_version_id=?', (name, row['batch_version_id']))
            return True

        def clean(value, field, required=False, max_len=500):
            value = (value or '').strip()
            if required and not value:
                raise ValueError(f'{field} required')
            return value

        def column_map(headers):
            lookup = {''.join(ch for ch in h.lower() if ch.isalnum()): h for h in headers}
            return lambda *aliases: next((lookup[a] for a in aliases if a in lookup), None)

        ns = dict(csv=csv, io=io, MAX_CSV_ROWS=50000, database_write_lock=no_lock,
                  validate_csv_upload=lambda *a: None, validate_month_key=lambda x: x,
                  csv_column_map=column_map, clean_text=clean, has_common_name=has_common_name,
                  get_db=get_db, active_batch_rows=active_rows,
                  update_common_name_effective=update_name, refresh_unmatched_log=lambda c: 0)
        exec(compile(ast.Module(body=nodes, type_ignores=[]), '<import_common>', 'exec'), ns)
        upload = ns['import_common_names_csv_bytes']
        data = b'ScheduleName,OpConFullBatchName,CommonName\nAPP005,OPCON_A,GPA Burial\n'
        self.assertEqual(upload(data, '2026-11'), 1)
        c = get_db()
        self.assertEqual(c.execute('SELECT commonname FROM BatchMaster').fetchone()[0], 'GPA Burial')
        self.assertEqual(c.execute('SELECT status FROM DailyRun').fetchone()[0], 'COMPLETED')
        c.close()
        with self.assertRaisesRegex(ValueError, 'found 0'):
            upload(b'ScheduleName,OpConFullBatchName,CommonName\nAPP999,OPCON_A,Other\n', '2026-11')
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            upload(data + b'APP005,OPCON_A,Other\n', '2026-11')


if __name__ == '__main__':
    unittest.main()
