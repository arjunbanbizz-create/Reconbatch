import ast
import csv
import io
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from match_diagnostics import batch_prefix, unmatched_rows, FIELDS


def master(name='J15.01.BI-SPSTG-MLY SSP ISSUANCE STAGING', schedule='APP015',
           batch='BI-SPSTG-MLY', effective_from='2026-10', effective_to=None, version=1):
    return dict(batch_version_id=version, schedulename=schedule, jobname=name,
                jobid=batch, effective_from=effective_from, effective_to=effective_to)


def run(name='J15.01.BI-SPSTG-MLY SSP ISSUANCE STAGING', schedule='APP015',
        when='2026-11-12'):
    return dict(scheduled_date=when, schedulename=schedule,
                opcon_full_batch_name=name, status='COMPLETED',
                source_file='daily.csv', source_row=2)


class PrefixTests(unittest.TestCase):
    def test_bi(self):
        self.assertEqual(batch_prefix('BI-TFISS-MLY'), 'BI')

    def test_in(self):
        self.assertEqual(batch_prefix('IN-RSDXV-ONR'), 'IN')

    def test_fallback_opcon(self):
        self.assertEqual(batch_prefix('', 'J14.01.BI-SSISS-WLY RIW/TANF'), 'BI')

    def test_unknown(self):
        self.assertEqual(batch_prefix('', 'SOME BATCH'), '--')


class DiagnosticTests(unittest.TestCase):
    def test_exact_match_not_logged(self):
        self.assertEqual(unmatched_rows([run()], [master()]), [])

    def test_exact_without_schedule_unique(self):
        self.assertEqual(unmatched_rows([run(schedule='')], [master()]), [])

    def test_near_name_logged_not_matched(self):
        out = unmatched_rows([run(name='J15.01.BI-SPSTG-MLY SSP ISSUANCE STAGNG')], [master()])
        self.assertEqual(out[0]['reason'], 'NEAR_NAME_MATCH')
        self.assertEqual(out[0]['suggested_batch_name'], 'BI-SPSTG-MLY')

    def test_same_batch_code_different_description(self):
        out = unmatched_rows([run(name='J15.01.BI-SPSTG-MLY')], [master()])
        self.assertEqual(out[0]['reason'], 'SAME_BATCH_CODE_DIFFERENT_NAME')
        self.assertEqual(out[0]['suggested_batch_name'], 'BI-SPSTG-MLY')

    def test_case_difference_is_only_suggestion(self):
        out = unmatched_rows([run(name='j15.01.bi-spstg-mly ssp issuance staging')], [master()])
        self.assertEqual(out[0]['reason'], 'NAME_CASE_OR_SPACING')

    def test_wrong_schedule_logged(self):
        out = unmatched_rows([run(schedule='APP999')], [master()])
        self.assertEqual(out[0]['reason'], 'SCHEDULE_MISMATCH')

    def test_ambiguous_scheduleless_logged(self):
        out = unmatched_rows([run(schedule='')], [master(), master(schedule='APP016', version=2)])
        self.assertEqual(out[0]['reason'], 'AMBIGUOUS_SCHEDULE')

    def test_inactive_master_logged(self):
        out = unmatched_rows([run()], [master(effective_from='2026-12')])
        self.assertEqual(out[0]['reason'], 'NO_ACTIVE_MASTER_FOR_MONTH')

    def test_no_close_match_logged_without_suggestion(self):
        out = unmatched_rows([run(name='NOT A REAL JOB')], [master()])
        self.assertEqual(out[0]['reason'], 'NO_CLOSE_MATCH')
        self.assertEqual(out[0]['suggested_master_opcon_full_batch_name'], '')

    def test_old_month_remains_valid(self):
        self.assertEqual(unmatched_rows([run(when='2026-10-12')],
                                        [master(effective_from='2026-10', effective_to='2026-10')]), [])


class LogGenerationTests(unittest.TestCase):
    def test_refresh_uses_sqlite_without_changing_master(self):
        # Execute only the refresh function AST, so this test has no Flask dependency.
        app_source = Path(__file__).resolve().parents[1].joinpath('app.py').read_text()
        tree = ast.parse(app_source)
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'refresh_unmatched_log')
        import match_diagnostics
        import tempfile as tempfile_mod
        import csv as csv_mod
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'logs' / 'unmatched_daily_matches.csv'
            ns = dict(UNMATCHED_LOG_PATH=path, UNMATCHED_FIELDS=FIELDS,
                      unmatched_rows=unmatched_rows, tempfile=tempfile_mod, csv=csv_mod, os=os)
            exec(compile(ast.Module(body=[node], type_ignores=[]), '<refresh>', 'exec'), ns)
            conn = sqlite3.connect(':memory:')
            conn.row_factory = sqlite3.Row
            conn.executescript('''
                CREATE TABLE DailyRun (id INTEGER, scheduled_date TEXT, schedulename TEXT,
                  opcon_full_batch_name TEXT, status TEXT, source_file TEXT, source_row INTEGER);
                CREATE TABLE BatchMaster (batch_version_id INTEGER, schedulename TEXT,
                  jobname TEXT, jobid TEXT, effective_from TEXT, effective_to TEXT);
            ''')
            conn.execute('INSERT INTO BatchMaster VALUES(?,?,?,?,?,?)',
                         (1, 'APP015', 'J15.01.BI-SPSTG-MLY SSP ISSUANCE STAGING',
                          'BI-SPSTG-MLY', '2026-10', None))
            conn.execute('INSERT INTO DailyRun VALUES(?,?,?,?,?,?,?)',
                         (1, '2026-11-12', 'APP015',
                          'J15.01.BI-SPSTG-MLY SSP ISSUANCE STAGNG', 'COMPLETED', 'daily.csv', 2))
            self.assertEqual(ns['refresh_unmatched_log'](conn), 1)
            with path.open(encoding='utf-8-sig', newline='') as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(rows[0]['reason'], 'NEAR_NAME_MATCH')
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM BatchMaster').fetchone()[0], 1)
            conn.execute('UPDATE DailyRun SET opcon_full_batch_name=?',
                         ('J15.01.BI-SPSTG-MLY SSP ISSUANCE STAGING',))
            self.assertEqual(ns['refresh_unmatched_log'](conn), 0)
            with path.open(encoding='utf-8-sig', newline='') as f:
                self.assertEqual(len(list(csv.DictReader(f))), 0)
            conn.close()


if __name__ == '__main__':
    unittest.main()
