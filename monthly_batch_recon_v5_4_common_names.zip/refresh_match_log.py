"""Rebuild unmatched CSV diagnostics from existing database without editing it."""
from app import database_write_lock, get_db, refresh_unmatched_log, UNMATCHED_LOG_PATH

with database_write_lock():
    conn = get_db()
    try:
        count = refresh_unmatched_log(conn)
    finally:
        conn.close()
print(f"Unmatched daily runs: {count}; log: {UNMATCHED_LOG_PATH}")
