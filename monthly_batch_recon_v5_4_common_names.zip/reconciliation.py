"""Pure-Python expected-week reconciliation rules (no Flask dependency).

A successful run in an earlier week can satisfy one future expected week.
Every actual run can satisfy at most one expected week. Exact-week observations
are reserved first; a failed/running exact-week observation is never hidden by
an earlier success.
"""


def week_of(scheduled_date):
    day = int(scheduled_date[8:10])
    return 1 if day <= 7 else 2 if day <= 14 else 3 if day <= 21 else 4


def status_for_matches(matches):
    statuses = {r['status'] for r in matches}
    if 'COMPLETED' in statuses:
        return 'COMPLETED'
    if 'FAILED' in statuses:
        return 'FAILED'
    if 'RUNNING' in statuses:
        return 'RUNNING'
    return 'PENDING'


def aggregate_card_status(job_statuses):
    statuses = list(job_statuses)
    if statuses and all(s in ('COMPLETED', 'COMPLETED_EARLY') for s in statuses):
        return 'COMPLETED_EARLY' if 'COMPLETED_EARLY' in statuses else 'COMPLETED'
    if 'FAILED' in statuses:
        return 'FAILED'
    if 'RUNNING' in statuses:
        return 'RUNNING'
    return 'PENDING'


def assign_expected_weeks(expected_weeks, runs):
    """Return (assignments, early_exceptions) for one master batch.

    assignments: {week: {'status', 'matches', 'early_run'}}
    early_exceptions: [{'actual_week', 'expected_week', 'run'}]

    Rules: exact-week observations take priority; then unused COMPLETED runs
    from strictly earlier weeks may satisfy pending future weeks in ascending
    expected-week order. The most recent eligible early run is chosen. All
    matching is limited to the selected calendar month by the caller.
    """
    weeks = sorted(set(expected_weeks))
    ordered = sorted(runs, key=lambda r: (r['scheduled_date'], r['loaded_at'], r['id']))
    used_ids = set()
    assignments = {}
    exceptions = []

    # First reserve every execution from an expected week so it cannot be
    # borrowed by another expected week, even if its status is FAILED.
    for week in weeks:
        same_week = [r for r in ordered if week_of(r['scheduled_date']) == week]
        used_ids.update(r['id'] for r in same_week)
        assignments[week] = {
            'status': status_for_matches(same_week),
            'matches': same_week,
            'early_run': None,
        }

    # Fill expected weeks that had no actual run in their own week.
    for week in weeks:
        if assignments[week]['matches']:
            continue
        eligible = [r for r in ordered
                    if r['id'] not in used_ids
                    and r['status'] == 'COMPLETED'
                    and week_of(r['scheduled_date']) < week]
        if not eligible:
            continue
        run = eligible[-1]
        used_ids.add(run['id'])
        assignments[week] = {
            'status': 'COMPLETED_EARLY',
            'matches': [run],
            'early_run': run,
        }
        exceptions.append({
            'actual_week': week_of(run['scheduled_date']),
            'expected_week': week,
            'run': run,
        })

    return assignments, exceptions
