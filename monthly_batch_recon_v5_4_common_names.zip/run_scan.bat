@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" scan_daily.py
) else (
  python scan_daily.py
)
endlocal
