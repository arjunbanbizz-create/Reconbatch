"""Common Name presentation rules for Batch Recon."""

def has_common_name(common_name, opcon_full_name):
    """Legacy imports sometimes copied OpCon into Common Name; treat as missing."""
    value = (common_name or '').strip()
    opcon = (opcon_full_name or '').strip()
    return bool(value and value.casefold() != opcon.casefold())


def display_common_name(common_name, opcon_full_name):
    return common_name.strip() if has_common_name(common_name, opcon_full_name) else 'Common name not configured'
