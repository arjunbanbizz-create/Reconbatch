"""Read-only diagnostics for daily-run-to-master matching.

Never changes BatchMaster or DailyRun, and never fuzzy-matches reconciliation.
Only provides suggestions for a human to review.
"""
from difflib import SequenceMatcher
import re

FIELDS = [
    'scheduled_date', 'source_file', 'source_row', 'daily_schedule',
    'daily_opcon_full_batch_name', 'daily_status', 'reason',
    'suggested_master_schedule', 'suggested_master_opcon_full_batch_name',
    'suggested_batch_name', 'similarity_pct', 'master_effective_from',
    'master_effective_to',
]


def batch_prefix(batch_name, opcon_name=''):
    """BI-TFISS-MLY -> BI; J14.01.BI-SSISS-WLY ... -> BI."""
    for text in (batch_name or '', opcon_name or ''):
        m = re.search(r'(?<![A-Z0-9])([A-Z]{2,6})-[A-Z0-9]+', str(text).upper())
        if m:
            return m.group(1)
    return '--'


def batch_code(value):
    match = re.search(r'(?<![A-Z0-9])([A-Z]{2,6}-[A-Z0-9]+(?:-[A-Z0-9]+)*)', str(value or '').upper())
    return match.group(1) if match else ''


def normalized(value):
    return ' '.join(str(value or '').upper().split())


def _active(master, ym):
    return master['effective_from'] <= ym and (not master['effective_to'] or master['effective_to'] >= ym)


def _candidate_score(run, master):
    left = normalized(run['opcon_full_batch_name'])
    right = normalized(master['jobname'])
    return SequenceMatcher(None, left, right, autojunk=False).ratio()


def _diagnose_one(run, masters):
    ym = run['scheduled_date'][:7]
    active = [m for m in masters if _active(m, ym)]
    opcon = run['opcon_full_batch_name']
    schedule = run.get('schedulename') or ''
    exact_name = [m for m in active if m['jobname'] == opcon]

    # Mirror the dashboard's exact-match policy, including schedule-less ambiguity.
    if schedule:
        if any(m['schedulename'] == schedule for m in exact_name):
            return None
    elif len({m['schedulename'] for m in exact_name}) == 1:
        return None

    if not schedule and len({m['schedulename'] for m in exact_name}) > 1:
        reason = 'AMBIGUOUS_SCHEDULE'
    elif exact_name and schedule:
        reason = 'SCHEDULE_MISMATCH'
    elif not active:
        reason = 'NO_ACTIVE_MASTER_FOR_MONTH'
    else:
        reason = 'NO_CLOSE_MATCH'

    # Prioritize candidates with matching schedule or batch code; consider the
    # complete active master for small sets, with a deterministic cap for scale.
    pool = active
    if not pool:
        pool = [m for m in masters if m['jobname'] == opcon]
    if not pool:
        pool = masters
    if len(pool) > 250:
        same_schedule = [m for m in pool if m['schedulename'] == schedule]
        prefix = batch_prefix('', opcon)
        same_prefix = [m for m in pool if batch_prefix(m['jobid'], m['jobname']) == prefix]
        chosen = {m['batch_version_id']: m for m in same_schedule + same_prefix}
        pool = list(chosen.values())[:250]
    run_code = batch_code(opcon)
    ranked = sorted(((_candidate_score(run, m), m) for m in pool),
                    key=lambda p: (
                        -(bool(schedule) and schedule == p[1]['schedulename']),
                        -(run_code != '' and run_code == batch_code(p[1]['jobid'])),
                        -p[0], p[1]['schedulename'], p[1]['jobname']))
    top = ranked[0] if ranked else None
    same_code = bool(top and run_code and run_code == batch_code(top[1]['jobid']))
    if top and reason == 'NO_CLOSE_MATCH':
        score, m = top
        if normalized(opcon) == normalized(m['jobname']):
            reason = 'NAME_CASE_OR_SPACING'
        elif score >= 0.75:
            reason = 'NEAR_NAME_MATCH'
        elif same_code:
            reason = 'SAME_BATCH_CODE_DIFFERENT_NAME'
        elif score >= 0.65:
            reason = 'POSSIBLE_MATCH_LOW_CONFIDENCE'
    if top and top[0] < 0.65 and not same_code and reason not in ('SCHEDULE_MISMATCH', 'AMBIGUOUS_SCHEDULE'):
        top = None  # Don't suggest a likely unrelated batch.
    m = top[1] if top else {}
    return {
        'scheduled_date': run['scheduled_date'],
        'source_file': run.get('source_file') or '',
        'source_row': run.get('source_row') or '',
        'daily_schedule': schedule,
        'daily_opcon_full_batch_name': opcon,
        'daily_status': run['status'],
        'reason': reason,
        'suggested_master_schedule': m.get('schedulename', ''),
        'suggested_master_opcon_full_batch_name': m.get('jobname', ''),
        'suggested_batch_name': m.get('jobid', ''),
        'similarity_pct': round(top[0] * 100, 1) if top else '',
        'master_effective_from': m.get('effective_from', ''),
        'master_effective_to': m.get('effective_to', '') or '',
    }


def unmatched_rows(daily_runs, master_rows):
    """Return unmatched daily runs with optional closest candidates.

    Exact matches are excluded. All other runs are logged, including runs with
    no credible candidate, so operators can audit missing mapping coverage.
    """
    masters = list(master_rows)
    return [diag for run in daily_runs if (diag := _diagnose_one(run, masters)) is not None]
