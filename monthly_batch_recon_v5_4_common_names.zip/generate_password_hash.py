import getpass
from werkzeug.security import generate_password_hash

password = getpass.getpass('Enter master password: ')
confirm = getpass.getpass('Confirm password: ')
if not password or password != confirm:
    raise SystemExit('Passwords do not match or are empty.')
print(generate_password_hash(password))
