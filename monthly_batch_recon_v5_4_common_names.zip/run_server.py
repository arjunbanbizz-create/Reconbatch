import os
from waitress import serve
from app import app

host = os.environ.get('HOST', '127.0.0.1')
port = int(os.environ.get('PORT', '8080'))
threads = int(os.environ.get('WAITRESS_THREADS', '4'))
serve(app, host=host, port=port, threads=threads, channel_timeout=60, cleanup_interval=30)
