import csv
import tempfile
import hashlib
import hmac
import io
import os
import secrets
import sqlite3
import time
from calendar import monthrange
from contextlib import contextmanager
from datetime import date, datetime
from functools import wraps
from pathlib import Path

from flask import (
    Flask, abort, flash, g, redirect, render_template, request, session, url_for, send_file
)
from werkzeug.security import check_password_hash, generate_password_hash
from reconciliation import week_of, aggregate_card_status, assign_expected_weeks
from match_diagnostics import batch_prefix, unmatched_rows, FIELDS as UNMATCHED_FIELDS
from common_names import has_common_name, display_common_name

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('BATCH_RECON_DB', BASE_DIR / 'batch_recon_v2.db'))
DAILY_CSV_DIR = Path(os.environ.get('DAILY_CSV_DIR', BASE_DIR / 'daily_csv'))
UNMATCHED_LOG_PATH = Path(os.environ.get('UNMATCHED_LOG_PATH', BASE_DIR / 'logs' / 'unmatched_daily_matches.csv'))
LOCK_PATH = Path(str(DB_PATH) + '.write.lock')
MAX_UPLOAD_MB = int(os.environ.get('MAX_UPLOAD_MB', '10'))
MAX_CSV_ROWS = int(os.environ.get('MAX_CSV_ROWS', '50000'))
MASTER_USERNAME = os.environ.get('MASTER_USERNAME', 'batchuser')
MASTER_PASSWORD = os.environ.get('MASTER_PASSWORD')
MASTER_PASSWORD_HASH = os.environ.get('MASTER_PASSWORD_HASH')
SECRET_KEY = os.environ.get('SECRET_KEY')
COOKIE_SECURE = os.environ.get('COOKIE_SECURE', '0') == '1'

if not SECRET_KEY:
    raise RuntimeError('SECRET_KEY is required. Set a strong random value before starting the app.')
if not MASTER_PASSWORD and not MASTER_PASSWORD_HASH:
    raise RuntimeError('Set MASTER_PASSWORD or MASTER_PASSWORD_HASH before starting the app.')

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config.update(
    MAX_CONTENT_LENGTH=MAX_UPLOAD_MB * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=COOKIE_SECURE,
    PERMANENT_SESSION_LIFETIME=1800,
)

FREQUENCIES = ['Daily', 'Weekly', 'BiWeekly', 'Semi-Monthly', 'Monthly', 'Quarterly', 'Annual', 'ADHOC', '36Month']
ALLOWED_STATUSES = {'COMPLETED', 'FAILED', 'RUNNING', 'PENDING', 'UNKNOWN'}
MAX_FIELD_LEN = 500
_login_attempts = {}


def _verify_master_password(candidate):
    if MASTER_PASSWORD_HASH:
        return check_password_hash(MASTER_PASSWORD_HASH, candidate or '')
    return hmac.compare_digest(MASTER_PASSWORD or '', candidate or '')


def _client_key():
    return request.remote_addr or 'unknown'


def _login_allowed():
    now = time.time()
    key = _client_key()
    attempts = [t for t in _login_attempts.get(key, []) if now - t < 900]
    _login_attempts[key] = attempts
    return len(attempts) < 5


def _record_login_failure():
    _login_attempts.setdefault(_client_key(), []).append(time.time())


def master_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get('master_authenticated'):
            return redirect(url_for('master_login', next=request.full_path if request.query_string else request.path))
        return view(*args, **kwargs)
    return wrapped


def csrf_token():
    token = session.get('_csrf_token')
    if not token:
        token = secrets.token_urlsafe(32)
        session['_csrf_token'] = token
    return token


@app.context_processor
def inject_security_context():
    return {'csrf_token': csrf_token, 'master_authenticated': bool(session.get('master_authenticated')),
            'csp_nonce': getattr(g, 'csp_nonce', '')}


@app.before_request
def verify_csrf():
    g.csp_nonce = secrets.token_urlsafe(16)
    if request.method == 'POST':
        expected = session.get('_csrf_token', '')
        supplied = request.form.get('_csrf_token', '') or request.headers.get('X-CSRF-Token', '')
        if not expected or not supplied or not hmac.compare_digest(expected, supplied):
            abort(400, description='Invalid or missing CSRF token.')


@app.after_request
def add_security_headers(response):
    nonce = getattr(g, 'csp_nonce', '')
    response.headers['Content-Security-Policy'] = (
        f"default-src 'self'; script-src 'self' 'nonce-{nonce}'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
    )
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'same-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    if COOKIE_SECURE:
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response


def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=60)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    conn.execute('PRAGMA busy_timeout = 60000')
    return conn


@contextmanager
def database_write_lock(timeout=60):
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    fh = open(LOCK_PATH, 'a+b')
    deadline = time.time() + timeout
    locked = False
    try:
        while not locked:
            try:
                if os.name == 'nt':
                    import msvcrt
                    if LOCK_PATH.stat().st_size == 0:
                        fh.write(b'0')
                        fh.flush()
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
            except (OSError, IOError):
                if time.time() >= deadline:
                    raise TimeoutError('Timed out waiting for database write lock.')
                time.sleep(0.2)
        yield
    finally:
        if locked:
            try:
                if os.name == 'nt':
                    import msvcrt
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
            except Exception:
                pass
        fh.close()


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    DAILY_CSV_DIR.mkdir(parents=True, exist_ok=True)
    with database_write_lock():
        conn = get_db()
        try:
            conn.execute('PRAGMA journal_mode = WAL')
            conn.execute('PRAGMA synchronous = NORMAL')
            conn.executescript('''
            CREATE TABLE IF NOT EXISTS BatchMaster (
                batch_version_id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_key TEXT NOT NULL,
                schedulename TEXT NOT NULL,
                jobname TEXT NOT NULL,
                jobid TEXT NOT NULL,
                frequency TEXT NOT NULL,
                commonname TEXT,
                weeks TEXT NOT NULL,
                effective_from TEXT NOT NULL,
                effective_to TEXT,
                created_at TEXT NOT NULL,
                created_by TEXT DEFAULT 'master',
                change_note TEXT,
                CHECK (effective_to IS NULL OR effective_to >= effective_from)
            );
            CREATE UNIQUE INDEX IF NOT EXISTS uq_batch_version_start
              ON BatchMaster(batch_key, effective_from);
            CREATE INDEX IF NOT EXISTS idx_batch_effective
              ON BatchMaster(effective_from, effective_to, schedulename);
            CREATE INDEX IF NOT EXISTS idx_batch_jobid ON BatchMaster(jobid);

            CREATE TABLE IF NOT EXISTS DailyRun (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scheduled_date TEXT NOT NULL,
                schedulename TEXT,
                opcon_full_batch_name TEXT NOT NULL,
                runtime TEXT,
                status TEXT NOT NULL,
                raw_status TEXT,
                source_file TEXT,
                source_hash TEXT,
                source_row INTEGER,
                import_type TEXT NOT NULL DEFAULT 'AUTO',
                loaded_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS ImportLog (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_file TEXT NOT NULL,
                source_hash TEXT NOT NULL,
                import_type TEXT NOT NULL,
                loaded_at TEXT NOT NULL,
                rows_loaded INTEGER NOT NULL DEFAULT 0,
                rows_updated INTEGER NOT NULL DEFAULT 0,
                note TEXT,
                UNIQUE(source_hash, import_type)
            );

            CREATE TABLE IF NOT EXISTS AuditLog (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                detail TEXT,
                remote_addr TEXT,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_audit_created_at ON AuditLog(created_at DESC);
            ''')
            # Migrate a legacy v4 DailyRun table to the OpCon-keyed schema.
            cols = {r['name'] for r in conn.execute('PRAGMA table_info(DailyRun)').fetchall()}
            if 'rundate' in cols or 'jobid' in cols:
                conn.executescript("""
                ALTER TABLE DailyRun RENAME TO DailyRun_legacy_v4;
                DROP INDEX IF EXISTS idx_daily_run_month;
                DROP INDEX IF EXISTS uq_daily_run_identity;
                CREATE TABLE DailyRun (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scheduled_date TEXT NOT NULL,
                    schedulename TEXT,
                    opcon_full_batch_name TEXT NOT NULL,
                    runtime TEXT,
                    status TEXT NOT NULL,
                    raw_status TEXT,
                    source_file TEXT,
                    source_hash TEXT,
                    source_row INTEGER,
                    import_type TEXT NOT NULL DEFAULT 'AUTO',
                    loaded_at TEXT NOT NULL
                );
                CREATE INDEX idx_daily_run_month ON DailyRun(scheduled_date, opcon_full_batch_name);
                CREATE UNIQUE INDEX uq_daily_run_identity
                  ON DailyRun(scheduled_date, ifnull(schedulename, ''), opcon_full_batch_name);
                """)
                legacy_cols = {r['name'] for r in conn.execute('PRAGMA table_info(DailyRun_legacy_v4)').fetchall()}
                if {'rundate','jobname','status','loaded_at'}.issubset(legacy_cols):
                    conn.execute("""INSERT OR IGNORE INTO DailyRun
                        (scheduled_date, schedulename, opcon_full_batch_name, runtime, status, raw_status,
                         source_file, source_hash, source_row, import_type, loaded_at)
                        SELECT rundate, schedulename, COALESCE(jobname, jobid), NULL, status, raw_status,
                               source_file, source_hash, source_row, import_type, loaded_at
                        FROM DailyRun_legacy_v4
                        WHERE COALESCE(jobname, jobid) IS NOT NULL""")
                conn.execute('DROP TABLE DailyRun_legacy_v4')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_daily_run_month ON DailyRun(scheduled_date, opcon_full_batch_name)')
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_daily_run_identity ON DailyRun(scheduled_date, ifnull(schedulename, ''), opcon_full_batch_name)")
            conn.commit()
        finally:
            conn.close()


def audit(action, detail=''):
    actor = session.get('master_user', 'system')
    remote = request.remote_addr
    with database_write_lock():
        conn = get_db()
        try:
            conn.execute('INSERT INTO AuditLog(actor, action, detail, remote_addr, created_at) VALUES(?,?,?,?,?)',
                         (actor, action, str(detail)[:2000], remote, datetime.now().isoformat(timespec='seconds')))
            conn.commit()
        finally:
            conn.close()


def month_key(year, month):
    return f'{year:04d}-{month:02d}'


def previous_month_key(ym):
    y, m = map(int, ym.split('-'))
    return f'{y - 1:04d}-12' if m == 1 else f'{y:04d}-{m - 1:02d}'


def validate_month_key(value):
    try:
        dt = datetime.strptime(value, '%Y-%m')
        return dt.strftime('%Y-%m')
    except Exception as exc:
        raise ValueError('Effective month must be YYYY-MM.') from exc


def clean_text(value, field, required=False, max_len=MAX_FIELD_LEN):
    text = (value or '').strip()
    if required and not text:
        raise ValueError(f'{field} is required.')
    if len(text) > max_len:
        raise ValueError(f'{field} exceeds {max_len} characters.')
    return text


def normalize_weeks(value):
    parts = value if isinstance(value, (list, tuple, set)) else str(value or '').replace(';', ',').split(',')
    weeks = sorted({int(str(p).strip()) for p in parts if str(p).strip()})
    if not weeks or any(w not in (1, 2, 3, 4) for w in weeks):
        raise ValueError('Weeks must contain one or more values from 1,2,3,4.')
    return ','.join(str(w) for w in weeks)


def weeks_list(value):
    return [int(x) for x in str(value or '').split(',') if x.strip().isdigit()]


def normalize_frequency(value):
    raw = clean_text(value, 'Frequency', required=True, max_len=40)
    lookup = {f.lower().replace('_', '').replace('-', '').replace(' ', ''): f for f in FREQUENCIES}
    lookup.update({'semimonthly': 'Semi-Monthly', 'biweekly': 'BiWeekly', 'yearly': 'Annual'})
    key = raw.lower().replace('_', '').replace('-', '').replace(' ', '')
    if key not in lookup:
        raise ValueError(f'Unsupported frequency: {raw}. Allowed: {", ".join(FREQUENCIES)}.')
    return lookup[key]


def normalize_status(value):
    v = clean_text(value, 'Status', required=True, max_len=50).lower()
    if v in {'success', 'successful', 'completed', 'complete', 'done', 'passed', 'ok'}:
        return 'COMPLETED'
    if v in {'failed', 'failure', 'error', 'aborted'}:
        return 'FAILED'
    if v in {'running', 'in progress', 'in_progress', 'started'}:
        return 'RUNNING'
    if v in {'pending', 'waiting', 'queued', 'scheduled'}:
        return 'PENDING'
    if v in {'unknown', 'n/a', 'na'}:
        return 'UNKNOWN'
    raise ValueError(f'Unsupported status: {value!r}.')


def parse_date(value):
    value = clean_text(value, 'Run date', required=True, max_len=40)
    for fmt in ('%Y-%m-%d', '%m/%d/%Y', '%Y/%m/%d', '%m-%d-%Y', '%Y%m%d'):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(value).date().isoformat()
    except Exception as exc:
        raise ValueError(f'Invalid run date: {value!r}') from exc


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def csv_column_map(fieldnames):
    headers = {h.lower().strip().replace(' ', '').replace('_', ''): h for h in (fieldnames or []) if h}
    def col(*names):
        for n in names:
            k = n.lower().replace(' ', '').replace('_', '')
            if k in headers:
                return headers[k]
        return None
    return col


def validate_csv_upload(filename, data):
    if not filename or not filename.lower().endswith('.csv'):
        raise ValueError('Only .csv files are accepted.')
    if len(data) > app.config['MAX_CONTENT_LENGTH']:
        raise ValueError(f'CSV exceeds {MAX_UPLOAD_MB} MB limit.')
    if not data:
        raise ValueError('CSV file is empty.')


def refresh_unmatched_log(conn):
    """Atomically regenerate diagnostics for currently unmatched DailyRun rows.

    Run under database_write_lock after DB commit. This file is informational:
    no candidate is ever automatically mapped to a master batch.
    """
    daily = [dict(r) for r in conn.execute('''SELECT scheduled_date, schedulename, opcon_full_batch_name, status,
        source_file, source_row FROM DailyRun ORDER BY scheduled_date, id''').fetchall()]
    masters = [dict(r) for r in conn.execute('''SELECT batch_version_id, schedulename, jobname, jobid,
        effective_from, effective_to FROM BatchMaster ORDER BY schedulename, jobname''').fetchall()]
    issues = unmatched_rows(daily, masters)
    UNMATCHED_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile('w', newline='', encoding='utf-8-sig',
                                         dir=UNMATCHED_LOG_PATH.parent,
                                         prefix='.unmatched-', suffix='.tmp', delete=False) as f:
            temp_name = f.name
            writer = csv.DictWriter(f, fieldnames=UNMATCHED_FIELDS)
            writer.writeheader()
            writer.writerows({k: ("'" + v if isinstance(v, str) and v.lstrip().startswith(('=', '+', '-', '@')) else v)
                              for k, v in row.items()} for row in issues)
        os.replace(temp_name, UNMATCHED_LOG_PATH)
    finally:
        if temp_name and os.path.exists(temp_name):
            os.unlink(temp_name)
    return len(issues)


def import_daily_csv_bytes(data, source_file, import_type='AUTO', replace_dates=False):
    validate_csv_upload(source_file, data)
    with database_write_lock():
        source_hash = sha256_bytes(data)
        conn = get_db()
        try:
            if import_type == 'AUTO':
                seen = conn.execute('SELECT 1 FROM ImportLog WHERE source_hash=? AND import_type=?',
                                    (source_hash, import_type)).fetchone()
                if seen:
                    return {'loaded': 0, 'updated': 0, 'skipped': True, 'hash': source_hash}

            try:
                text = data.decode('utf-8-sig')
            except UnicodeDecodeError as exc:
                raise ValueError('CSV must be UTF-8 encoded.') from exc
            reader = csv.DictReader(io.StringIO(text))
            if not reader.fieldnames:
                raise ValueError('CSV has no header row.')
            col = csv_column_map(reader.fieldnames)
            c_date = col('scheduled_date', 'scheduleddate', 'schedule_date', 'rundate', 'run_date', 'date')
            c_opcon = col('opcon_full_batch_name', 'opconfullbatchname', 'opcon_batch_name', 'jobname', 'job_name')
            c_runtime = col('runtime', 'run_time', 'duration', 'elapsedtime', 'elapsed_time')
            c_status = col('status', 'runstatus', 'run_status')
            c_schedule = col('schedulename', 'schedule_name', 'schedule')
            if not c_date or not c_opcon or not c_status:
                raise ValueError('Daily run CSV requires scheduled_date, opcon_full_batch_name, and status. runtime and schedulename are optional.')

            parsed = []
            for rownum, row in enumerate(reader, start=2):
                if rownum > MAX_CSV_ROWS + 1:
                    raise ValueError(f'CSV exceeds maximum of {MAX_CSV_ROWS} data rows.')
                opcon = clean_text(row.get(c_opcon), f'opcon_full_batch_name at row {rownum}', max_len=500)
                if not opcon:
                    continue
                raw_status = clean_text(row.get(c_status), f'status at row {rownum}', required=True, max_len=50)
                parsed.append({
                    'rownum': rownum,
                    'scheduled_date': parse_date(row.get(c_date)),
                    'schedulename': clean_text(row.get(c_schedule), 'schedulename', max_len=200) if c_schedule else None,
                    'opcon_full_batch_name': opcon,
                    'runtime': clean_text(row.get(c_runtime), 'runtime', max_len=100) if c_runtime else None,
                    'raw_status': raw_status,
                    'status': normalize_status(raw_status),
                })

            if replace_dates and parsed:
                dates = sorted({r['scheduled_date'] for r in parsed})
                placeholders = ','.join('?' for _ in dates)
                conn.execute(f'DELETE FROM DailyRun WHERE scheduled_date IN ({placeholders})', dates)

            loaded = updated = 0
            now = datetime.now().isoformat(timespec='seconds')
            for r in parsed:
                existing = conn.execute("""SELECT id FROM DailyRun
                    WHERE scheduled_date=? AND ifnull(schedulename,'')=ifnull(?, '')
                      AND opcon_full_batch_name=?""",
                    (r['scheduled_date'], r['schedulename'], r['opcon_full_batch_name'])).fetchone()
                params = (r['runtime'], r['status'], r['raw_status'], Path(source_file).name, source_hash,
                          r['rownum'], import_type, now, r['scheduled_date'], r['schedulename'],
                          r['opcon_full_batch_name'])
                if existing:
                    conn.execute("""UPDATE DailyRun SET runtime=?, status=?, raw_status=?, source_file=?,
                        source_hash=?, source_row=?, import_type=?, loaded_at=?
                        WHERE scheduled_date=? AND ifnull(schedulename,'')=ifnull(?, '')
                          AND opcon_full_batch_name=?""", params)
                    updated += 1
                else:
                    conn.execute("""INSERT INTO DailyRun
                        (runtime, status, raw_status, source_file, source_hash, source_row, import_type, loaded_at,
                         scheduled_date, schedulename, opcon_full_batch_name)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", params)
                    loaded += 1

            conn.execute("""INSERT OR IGNORE INTO ImportLog
                (source_file, source_hash, import_type, loaded_at, rows_loaded, rows_updated, note)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (Path(source_file).name, source_hash, import_type, now, loaded, updated,
                 'Replace dates' if replace_dates else 'Upsert'))
            conn.commit()
            try:
                unmatched_count = refresh_unmatched_log(conn)
                log_error = None
            except OSError as exc:
                unmatched_count = None
                log_error = str(exc)
            return {'loaded': loaded, 'updated': updated, 'skipped': False, 'hash': source_hash,
                    'unmatched': unmatched_count, 'log_error': log_error}
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def scan_daily_directory():
    DAILY_CSV_DIR.mkdir(parents=True, exist_ok=True)
    results = []
    for path in sorted(DAILY_CSV_DIR.glob('*.csv')):
        try:
            result = import_daily_csv_bytes(path.read_bytes(), path.name, import_type='AUTO')
            results.append((path.name, result, None))
        except Exception as exc:
            results.append((path.name, None, str(exc)))
    return results


def active_batch_rows(conn, year, month):
    ym = month_key(year, month)
    return conn.execute('''SELECT * FROM BatchMaster WHERE effective_from <= ?
        AND (effective_to IS NULL OR effective_to >= ?)
        ORDER BY schedulename, commonname, jobname, jobid''', (ym, ym)).fetchall()


def create_batch_version(conn, data, effective_from, batch_key=None, change_note='Added'):
    effective_from = validate_month_key(effective_from)
    weeks = normalize_weeks(data.get('weeks'))
    jobid = clean_text(data.get('jobid'), 'Job ID', required=True, max_len=150)
    schedulename = clean_text(data.get('schedulename'), 'Schedule name', required=True, max_len=200)
    jobname = clean_text(data.get('jobname'), 'Job name', required=True, max_len=500)
    commonname = clean_text(data.get('commonname'), 'Common name', required=True, max_len=200)
    if not has_common_name(commonname, jobname):
        raise ValueError('Common Name must be different from the full OpCon batch name.')
    frequency = normalize_frequency(data.get('frequency'))
    if batch_key is None:
        batch_key = hashlib.sha1(f'{schedulename}|{jobid}|{datetime.now().isoformat()}'.encode()).hexdigest()[:20]
    conn.execute('''INSERT INTO BatchMaster
        (batch_key, schedulename, jobname, jobid, frequency, commonname, weeks,
         effective_from, effective_to, created_at, created_by, change_note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)''',
        (batch_key, schedulename, jobname, jobid, frequency, commonname, weeks, effective_from,
         datetime.now().isoformat(timespec='seconds'), session.get('master_user', 'system'),
         clean_text(change_note, 'Change note', max_len=500)))
    return batch_key


def update_batch_effective(conn, version_id, data, effective_from):
    current = conn.execute('SELECT * FROM BatchMaster WHERE batch_version_id=?', (version_id,)).fetchone()
    if not current:
        raise ValueError('Batch version not found.')
    effective_from = validate_month_key(effective_from)
    if effective_from < current['effective_from']:
        raise ValueError('An edit cannot start before the selected version starts.')
    clean = {
        'schedulename': clean_text(data.get('schedulename'), 'Schedule name', required=True, max_len=200),
        'jobname': clean_text(data.get('jobname'), 'Job name', required=True, max_len=500),
        'jobid': clean_text(data.get('jobid'), 'Job ID', required=True, max_len=150),
        'frequency': normalize_frequency(data.get('frequency')),
        'commonname': clean_text(data.get('commonname'), 'Common name', required=True, max_len=200),
        'weeks': normalize_weeks(data.get('weeks')),
        'change_note': clean_text(data.get('change_note'), 'Change note', max_len=500) or 'Changed',
    }
    if not has_common_name(clean['commonname'], clean['jobname']):
        raise ValueError('Common Name must be different from the full OpCon batch name.')
    if effective_from == current['effective_from']:
        conn.execute('''UPDATE BatchMaster SET schedulename=?, jobname=?, jobid=?, frequency=?, commonname=?,
            weeks=?, change_note=?, created_by=? WHERE batch_version_id=?''',
            (clean['schedulename'], clean['jobname'], clean['jobid'], clean['frequency'], clean['commonname'],
             clean['weeks'], clean['change_note'], session.get('master_user', 'system'), version_id))
    else:
        conn.execute('UPDATE BatchMaster SET effective_to=? WHERE batch_version_id=?',
                     (previous_month_key(effective_from), version_id))
        create_batch_version(conn, clean, effective_from, batch_key=current['batch_key'],
                             change_note=clean['change_note'])


def retire_batch_effective(conn, version_id, effective_from):
    current = conn.execute('SELECT * FROM BatchMaster WHERE batch_version_id=?', (version_id,)).fetchone()
    if not current:
        raise ValueError('Batch version not found.')
    effective_from = validate_month_key(effective_from)
    if effective_from <= current['effective_from']:
        conn.execute('DELETE FROM BatchMaster WHERE batch_version_id=?', (version_id,))
    else:
        conn.execute('UPDATE BatchMaster SET effective_to=? WHERE batch_version_id=?',
                     (previous_month_key(effective_from), version_id))


def import_batch_master_csv_bytes(data, effective_from, source_file='batch_master.csv'):
    validate_csv_upload(source_file, data)
    effective_from = validate_month_key(effective_from)
    with database_write_lock():
        try:
            reader = csv.DictReader(io.StringIO(data.decode('utf-8-sig')))
        except UnicodeDecodeError as exc:
            raise ValueError('CSV must be UTF-8 encoded.') from exc
        if not reader.fieldnames:
            raise ValueError('Batch master CSV has no header row.')
        col = csv_column_map(reader.fieldnames)
        c_schedule = col('schedulename', 'schedule')
        c_jobname = col('jobname', 'opconfullbatchname', 'opcon')
        c_jobid = col('jobid', 'batchname', 'batch')
        c_common = col('commonname', 'common')
        c_freq = col('frequency', 'freq')
        c_weeks = col('weeks', 'week')
        if not all([c_schedule, c_jobname, c_jobid, c_common, c_freq, c_weeks]):
            raise ValueError('Batch master CSV requires ScheduleName, OpConFullBatchName, BatchName, CommonName, Frequency, and Weeks. CommonName cannot be omitted.')
        conn = get_db()
        try:
            count = 0
            for rownum, row in enumerate(reader, start=2):
                if rownum > MAX_CSV_ROWS + 1:
                    raise ValueError(f'CSV exceeds maximum of {MAX_CSV_ROWS} data rows.')
                if not (row.get(c_jobid) or '').strip():
                    continue
                create_batch_version(conn, {
                    'schedulename': row.get(c_schedule), 'jobname': row.get(c_jobname), 'jobid': row.get(c_jobid),
                    'commonname': row.get(c_common),
                    'frequency': row.get(c_freq), 'weeks': row.get(c_weeks)
                }, effective_from, change_note='Master CSV import')
                count += 1
            conn.commit()
            refresh_unmatched_log(conn)
            return count
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()




def update_common_name_effective(conn, current, common_name, effective_from):
    """Update only Common Name while preserving effective-dated Master history."""
    effective_from = validate_month_key(effective_from)
    common_name = clean_text(common_name, 'Common Name', required=True, max_len=200)
    if not has_common_name(common_name, current['jobname']):
        raise ValueError('Common Name must differ from the full OpCon batch name.')
    if current['effective_from'] > effective_from or (current['effective_to'] and current['effective_to'] < effective_from):
        raise ValueError('Selected Master version is not active in the chosen month.')
    if has_common_name(current['commonname'], current['jobname']) and current['commonname'].strip() == common_name:
        return False
    next_version = conn.execute("""SELECT effective_from FROM BatchMaster
        WHERE batch_key=? AND effective_from>? ORDER BY effective_from LIMIT 1""",
        (current['batch_key'], effective_from)).fetchone()
    values = dict(current)
    values['commonname'] = common_name
    values['change_note'] = 'Common Name correction'
    update_batch_effective(conn, current['batch_version_id'], values, effective_from)
    if next_version and effective_from > current['effective_from']:
        conn.execute("""UPDATE BatchMaster SET effective_to=?
            WHERE batch_key=? AND effective_from=?""",
            (previous_month_key(next_version['effective_from']), current['batch_key'], effective_from))
    return True


def import_common_names_csv_bytes(data, effective_from, source_file='common_names.csv'):
    """Bulk correction by exact schedule + full OpCon name. Never add/retire batches."""
    validate_csv_upload(source_file, data)
    effective_from = validate_month_key(effective_from)
    try:
        reader = csv.DictReader(io.StringIO(data.decode('utf-8-sig')))
    except UnicodeDecodeError as exc:
        raise ValueError('Common Name CSV must be UTF-8 encoded.') from exc
    if not reader.fieldnames:
        raise ValueError('Common Name CSV has no header row.')
    col = csv_column_map(reader.fieldnames)
    c_schedule = col('schedulename', 'schedule')
    c_opcon = col('opconfullbatchname', 'jobname', 'opcon')
    c_common = col('commonname', 'common')
    if not all([c_schedule, c_opcon, c_common]):
        raise ValueError('Required CSV columns: ScheduleName, OpConFullBatchName, CommonName.')
    records = []
    seen = set()
    for rownum, row in enumerate(reader, 2):
        if rownum > MAX_CSV_ROWS + 1:
            raise ValueError(f'CSV exceeds {MAX_CSV_ROWS} data rows.')
        if not any((v or '').strip() for v in row.values() if isinstance(v, str)):
            continue
        schedule = clean_text(row.get(c_schedule), f'ScheduleName row {rownum}', required=True, max_len=200)
        opcon = clean_text(row.get(c_opcon), f'OpConFullBatchName row {rownum}', required=True, max_len=500)
        common = clean_text(row.get(c_common), f'CommonName row {rownum}', required=True, max_len=200)
        if not has_common_name(common, opcon):
            raise ValueError(f'Row {rownum}: CommonName must differ from OpConFullBatchName.')
        key = (schedule, opcon)
        if key in seen:
            raise ValueError(f'Row {rownum}: duplicate ScheduleName + OpConFullBatchName.')
        seen.add(key)
        records.append((rownum, key, common))
    if not records:
        raise ValueError('No Common Name corrections found.')
    with database_write_lock():
        conn = get_db()
        try:
            y, m = map(int, effective_from.split('-'))
            active = active_batch_rows(conn, y, m)
            index = {}
            for b in active:
                index.setdefault((b['schedulename'], b['jobname']), []).append(b)
            changes = []
            for rownum, key, common in records:
                matches = index.get(key, [])
                if len(matches) != 1:
                    raise ValueError(f'Row {rownum}: expected exactly one active Master batch for {key!r}; found {len(matches)}. No changes saved.')
                changes.append((matches[0], common))
            updated = sum(bool(update_common_name_effective(conn, b, name, effective_from)) for b, name in changes)
            conn.commit()
            refresh_unmatched_log(conn)
            return updated
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def month_bounds(year, month):
    start = date(year, month, 1)
    end = date(year + 1, 1, 1) if month == 12 else date(year, month + 1, 1)
    return start.isoformat(), end.isoformat()


def build_dashboard(year, month):
    conn = get_db()
    try:
        start, end = month_bounds(year, month)
        master = active_batch_rows(conn, year, month)
        runs = conn.execute("""SELECT * FROM DailyRun WHERE scheduled_date>=? AND scheduled_date<?
                               ORDER BY scheduled_date, loaded_at""", (start, end)).fetchall()

        # Resolve each daily run to exactly one schedule. A supplied schedule
        # must match; schedule-less rows are usable only for unique OpCon names.
        opcon_schedules = {}
        for b in master:
            opcon_schedules.setdefault(b['jobname'], set()).add(b['schedulename'])

        runs_by_batch = {}
        latest_rundate = None
        for r in runs:
            opcon = r['opcon_full_batch_name']
            latest_rundate = max(latest_rundate or r['scheduled_date'], r['scheduled_date'])
            if r['schedulename']:
                schedule = r['schedulename']
                if schedule not in opcon_schedules.get(opcon, set()):
                    continue  # Do not borrow a run from another schedule.
            else:
                candidates = opcon_schedules.get(opcon, set())
                if len(candidates) != 1:
                    continue  # Ambiguous schedule-less OpCon names cannot match.
                schedule = next(iter(candidates))
            runs_by_batch.setdefault((schedule, opcon), []).append(r)

        schedules = {}
        unique_jobs = set()
        early_exception_count = 0
        for b in master:
            sch = schedules.setdefault(b['schedulename'], {
                'name': b['schedulename'], 'weeks': {1: {}, 2: {}, 3: {}, 4: {}},
                'exceptions': {1: [], 2: [], 3: [], 4: []},
                'pending_by_week': {1: 0, 2: 0, 3: 0, 4: 0}, 'pending_total': 0,
                'pending_items': []
            })
            unique_jobs.add((b['schedulename'], b['jobname']))
            expected_weeks = weeks_list(b['weeks'])
            assignments, exceptions = assign_expected_weeks(
                expected_weeks, runs_by_batch.get((b['schedulename'], b['jobname']), []))
            common = display_common_name(b['commonname'], b['jobname'])
            common_missing = not has_common_name(b['commonname'], b['jobname'])
            card_group_key = common if not common_missing else ('__missing__', b['batch_key'])
            for exc in exceptions:
                run = exc['run']
                sch['exceptions'][exc['actual_week']].append({
                    'commonname': common, 'jobname': b['jobname'], 'jobid': b['jobid'],
                    'frequency': b['frequency'], 'expected_week': exc['expected_week'],
                    'actual_week': exc['actual_week'], 'scheduled_date': run['scheduled_date'],
                    'runtime': run['runtime'], 'status': run['status']
                })
                early_exception_count += 1
            for week in expected_weeks:
                assignment = assignments[week]
                matches = assignment['matches']
                status = assignment['status']
                if status not in ('COMPLETED', 'COMPLETED_EARLY'):
                    sch['pending_by_week'][week] += 1
                    sch['pending_total'] += 1
                    # One outstanding item per expected batch/week, not per card.
                    # Keep failed/running jobs visible: the existing pending
                    # counter includes every job that has not completed.
                    sch['pending_items'].append({
                        'schedule': b['schedulename'], 'week': week,
                        'commonname': common, 'jobid': b['jobid'],
                        'jobname': b['jobname'], 'status': status,
                        'last_run': max((r['scheduled_date'] for r in matches), default=None),
                    })
                card = sch['weeks'][week].setdefault(card_group_key, {
                    'commonname': common, 'common_missing': common_missing,
                    'frequency': b['frequency'], 'jobs': [], 'statuses': [],
                    'last_run': None, 'last_runtime': None
                })
                latest_match = max(matches, key=lambda r: (r['scheduled_date'], r['loaded_at'], r['id'])) if matches else None
                last_run = latest_match['scheduled_date'] if latest_match else None
                last_runtime = latest_match['runtime'] if latest_match else None
                early_run = assignment['early_run']
                card['jobs'].append({
                    'jobname': b['jobname'], 'jobid': b['jobid'], 'status': status,
                    'last_run': last_run, 'runtime': last_runtime, 'frequency': b['frequency'],
                    'actual_week': week_of(last_run) if last_run else None,
                    'expected_week': week, 'early': early_run is not None,
                    'prefix': batch_prefix(b['jobid'], b['jobname'])
                })
                card['statuses'].append(status)
                if last_run and (not card['last_run'] or last_run >= card['last_run']):
                    card['last_run'] = last_run
                    card['last_runtime'] = last_runtime

        card_count = 0
        schedule_list = []
        for sch in schedules.values():
            for w in range(1, 5):
                cards = []
                for card in sch['weeks'][w].values():
                    card['status'] = aggregate_card_status(card.pop('statuses'))
                    prefixes = {j['prefix'] for j in card['jobs']}
                    card['prefix'] = next(iter(prefixes)) if len(prefixes) == 1 else 'MIX'
                    cards.append(card)
                    card_count += 1
                sch['weeks'][w] = cards
            schedule_list.append(sch)
        pending_by_schedule = {}
        all_pending = []
        for sch in schedule_list:
            items = sorted(sch['pending_items'],
                           key=lambda x: (x['week'], x['commonname'].casefold(), x['jobid']))
            pending_by_schedule[sch['name']] = items
            all_pending.extend(items)
        all_pending.sort(key=lambda x: (x['schedule'], x['week'], x['commonname'].casefold(), x['jobid']))
        return {'schedules': schedule_list, 'latest_rundate': latest_rundate,
                'pending_lists': {'all': all_pending, 'schedules': pending_by_schedule},
                'stats': {'schedules': len(schedule_list), 'cards': card_count, 'jobs': len(unique_jobs),
                          'pending': sum(s['pending_total'] for s in schedule_list),
                          'early_exceptions': early_exception_count}}
    finally:
        conn.close()


def month_nav(year, month):
    prev_y, prev_m = (year - 1, 12) if month == 1 else (year, month - 1)
    next_y, next_m = (year + 1, 1) if month == 12 else (year, month + 1)
    return prev_y, prev_m, next_y, next_m


@app.route('/login', methods=['GET', 'POST'])
def master_login():
    if request.method == 'POST':
        if not _login_allowed():
            flash('Too many failed login attempts. Try again later.', 'error')
            return render_template('login.html'), 429
        username = clean_text(request.form.get('username'), 'Username', max_len=100)
        password = request.form.get('password') or ''
        if hmac.compare_digest(username, MASTER_USERNAME) and _verify_master_password(password):
            session.clear()
            session['master_authenticated'] = True
            session['master_user'] = MASTER_USERNAME
            session.permanent = True
            csrf_token()
            _login_attempts.pop(_client_key(), None)
            audit('LOGIN', 'Master login successful')
            target = request.form.get('next') or url_for('master_view')
            if not target.startswith('/') or target.startswith('//'):
                target = url_for('master_view')
            return redirect(target)
        _record_login_failure()
        flash('Invalid username or password.', 'error')
    return render_template('login.html', next=request.args.get('next', ''))


@app.post('/logout')
@master_required
def master_logout():
    audit('LOGOUT', 'Master logout')
    session.clear()
    return redirect(url_for('home'))


@app.route('/')
def home():
    today = date.today()
    return redirect(url_for('user_month_view', year=today.year, month=today.month))


@app.route('/month/<int:year>/<int:month>')
def user_month_view(year, month):
    if month not in range(1, 13):
        return 'Invalid month', 400
    data = build_dashboard(year, month)
    prev_y, prev_m, next_y, next_m = month_nav(year, month)
    return render_template('user_month.html', **data, year=year, month=month,
                           month_name=date(year, month, 1).strftime('%B %Y'),
                           month_short=date(year, month, 1).strftime('%b').upper(),
                           prev_y=prev_y, prev_m=prev_m, next_y=next_y, next_m=next_m)


@app.route('/master', methods=['GET'])
@master_required
def master_view():
    today = date.today()
    ym = request.args.get('month', month_key(today.year, today.month))
    try:
        ym = validate_month_key(ym)
    except ValueError:
        ym = month_key(today.year, today.month)
    y, m = map(int, ym.split('-'))
    conn = get_db()
    try:
        batches = active_batch_rows(conn, y, m)
        missing_common = [b for b in batches if not has_common_name(b['commonname'], b['jobname'])]
        imports = conn.execute('SELECT * FROM ImportLog ORDER BY loaded_at DESC LIMIT 20').fetchall()
        audits = conn.execute('SELECT * FROM AuditLog ORDER BY created_at DESC LIMIT 20').fetchall()
    finally:
        conn.close()
    unmatched_count = None
    if UNMATCHED_LOG_PATH.is_file():
        with UNMATCHED_LOG_PATH.open('r', encoding='utf-8-sig', newline='') as f:
            unmatched_count = max(0, sum(1 for _ in csv.reader(f)) - 1)
    return render_template('master.html', batches=batches, missing_common=missing_common, imports=imports, audits=audits,
                           selected_month=ym, csv_dir=str(DAILY_CSV_DIR), frequencies=FREQUENCIES,
                           db_path=str(DB_PATH), master_user=session.get('master_user'),
                           unmatched_log_path=str(UNMATCHED_LOG_PATH), unmatched_count=unmatched_count)


@app.get('/master/unmatched-log')
@master_required
def master_unmatched_log():
    if not UNMATCHED_LOG_PATH.is_file():
        abort(404, description='No diagnostic log yet. Import a daily CSV or regenerate the log.')
    return send_file(UNMATCHED_LOG_PATH, as_attachment=True,
                     download_name='unmatched_daily_matches.csv', mimetype='text/csv')


@app.post('/master/unmatched-log/refresh')
@master_required
def master_refresh_unmatched_log():
    try:
        with database_write_lock():
            conn = get_db()
            try:
                count = refresh_unmatched_log(conn)
            finally:
                conn.close()
        audit('UNMATCHED_LOG_REFRESH', f'{count} unmatched daily runs')
        flash(f'Diagnostics regenerated: {count} unmatched daily runs.', 'success')
    except Exception as exc:
        flash(f'Unable to regenerate diagnostics: {exc}', 'error')
    return redirect(url_for('master_view'))


@app.post('/master/batch/add')
@master_required
def master_batch_add():
    effective = request.form.get('effective_from')
    try:
        with database_write_lock():
            conn = get_db()
            try:
                create_batch_version(conn, request.form, effective, change_note=request.form.get('change_note') or 'Added')
                conn.commit()
                refresh_unmatched_log(conn)
            finally:
                conn.close()
        audit('BATCH_ADD', f'{request.form.get("jobid", "")} effective {effective}')
        flash(f'Batch added effective {effective}.', 'success')
    except Exception as exc:
        flash(str(exc), 'error')
    return redirect(url_for('master_view', month=effective))


@app.post('/master/batch/<int:version_id>/edit')
@master_required
def master_batch_edit(version_id):
    effective = request.form.get('effective_from')
    try:
        with database_write_lock():
            conn = get_db()
            try:
                update_batch_effective(conn, version_id, request.form, effective)
                conn.commit()
                refresh_unmatched_log(conn)
            finally:
                conn.close()
        audit('BATCH_EDIT', f'version {version_id} effective {effective}')
        flash(f'Batch change saved effective {effective}. Earlier months were preserved.', 'success')
    except Exception as exc:
        flash(str(exc), 'error')
    return redirect(url_for('master_view', month=effective))


@app.post('/master/batch/<int:version_id>/retire')
@master_required
def master_batch_retire(version_id):
    effective = request.form.get('effective_from')
    try:
        with database_write_lock():
            conn = get_db()
            try:
                retire_batch_effective(conn, version_id, effective)
                conn.commit()
                refresh_unmatched_log(conn)
            finally:
                conn.close()
        audit('BATCH_RETIRE', f'version {version_id} effective {effective}')
        flash(f'Batch removed effective {effective}. Earlier months were preserved.', 'success')
    except Exception as exc:
        flash(str(exc), 'error')
    return redirect(url_for('master_view', month=effective))



@app.post('/master/import/common-names')
@master_required
def master_import_common_names():
    f = request.files.get('file')
    effective = request.form.get('effective_from')
    if not f or not f.filename:
        flash('Choose a Common Names CSV file.', 'error')
        return redirect(url_for('master_view', month=effective))
    try:
        data = f.read(app.config['MAX_CONTENT_LENGTH'] + 1)
        count = import_common_names_csv_bytes(data, effective, f.filename)
        audit('COMMON_NAME_IMPORT', f'{Path(f.filename).name}: {count} names updated effective {effective}')
        flash(f'{count} Common Names updated effective {effective}. Daily run records were not changed.', 'success')
    except Exception as exc:
        flash(str(exc), 'error')
    return redirect(url_for('master_view', month=effective))


@app.post('/master/import/daily')
@master_required
def master_import_daily():
    f = request.files.get('file')
    replace_dates = request.form.get('replace_dates') == '1'
    if not f or not f.filename:
        flash('Choose a daily-run CSV file.', 'error')
        return redirect(url_for('master_view'))
    try:
        data = f.read(app.config['MAX_CONTENT_LENGTH'] + 1)
        result = import_daily_csv_bytes(data, f.filename, import_type='MANUAL', replace_dates=replace_dates)
        audit('DAILY_IMPORT', f'{Path(f.filename).name}: {result["loaded"]} new, {result["updated"]} updated; replace={replace_dates}')
        flash(f"Daily CSV imported: {result['loaded']} new, {result['updated']} updated; {result.get('unmatched')} unmatched in diagnostics.", 'success')
        if result.get('log_error'):
            flash('Daily data was saved, but diagnostic log generation failed: ' + result['log_error'], 'error')
    except Exception as exc:
        flash(str(exc), 'error')
    return redirect(url_for('master_view'))


@app.post('/master/import/batches')
@master_required
def master_import_batches():
    f = request.files.get('file')
    effective = request.form.get('effective_from')
    if not f or not f.filename:
        flash('Choose a batch-master CSV file.', 'error')
        return redirect(url_for('master_view', month=effective))
    try:
        data = f.read(app.config['MAX_CONTENT_LENGTH'] + 1)
        count = import_batch_master_csv_bytes(data, effective, f.filename)
        audit('BATCH_IMPORT', f'{Path(f.filename).name}: {count} rows effective {effective}')
        flash(f'{count} batch rows imported effective {effective}.', 'success')
    except Exception as exc:
        flash(str(exc), 'error')
    return redirect(url_for('master_view', month=effective))


@app.post('/master/scan')
@master_required
def master_scan():
    results = scan_daily_directory()
    loaded = sum((r or {}).get('loaded', 0) + (r or {}).get('updated', 0) for _, r, e in results if r and not e)
    errors = [f'{name}: {err}' for name, r, err in results if err]
    audit('MANUAL_SCAN', f'{loaded} rows loaded/updated; errors={len(errors)}')
    if errors:
        flash('Scan completed with errors: ' + '; '.join(errors), 'error')
    else:
        flash(f'Filesystem scan complete; {loaded} rows loaded/updated.', 'success')
    return redirect(url_for('master_view'))


# Initialize schema/WAL during import so Waitress and scheduled scanner use the same DB settings.
init_db()


if __name__ == '__main__':
    raise SystemExit('Use run_server.py (Waitress) for this production build.')
