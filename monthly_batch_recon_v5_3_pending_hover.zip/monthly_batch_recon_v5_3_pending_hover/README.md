# Batch Reconciliation v5.3 — pending-list hover

This update builds on v5.2 and preserves all existing batch reconciliation, early-run exception, CSV import, Master authentication, and unmatched diagnostic logging features.

## New pending-count hover

- Hover over **Pending Jobs** in the top summary to see every outstanding expected batch/week across all schedules.
- Hover over a schedule's **Pending** column count to see only outstanding batches for that schedule.
- Each list entry shows **Common Name**, **W1–W4 expected week**, **batch code**, **full OpCon name**, **status**, and last run date (when present).
- The popover is scrollable and floats above the grid, so it is not clipped by the horizontal/vertical schedule scroll area.
- Click a count to pin/unpin the list (useful on touch screens); Escape or × closes it. Keyboard focus also opens the list.
- Counts are **expected batch/week entries** (one job expected in two weeks appears twice). This exactly matches the existing pending counters.
- Existing **Pending Jobs** counts include every unresolved status: `PENDING`, `FAILED`, and `RUNNING`. The popover distinguishes these statuses. Completed and Completed Early are excluded.
- The list is read-only and computed from the same reconciliation results as the dashboard; no DB schema or CSV changes.

## Upgrade from v5.2 on Windows

1. Stop Waitress and pause the hourly CSV scanner.
2. Back up your live SQLite DB (set by `BATCH_RECON_DB`).
3. Extract **v5.3 update patch** into `C:\BatchRecon`, overwriting `app.py` and `templates\user_month.html`.
4. Restart `start_server.bat` and resume the CSV scanner.
5. Refresh the dashboard and hover over either the overall Pending Jobs count or a schedule's Pending column count.

No dependency reinstall, schema migration, or CSV reimport is required. The patch contains no database.

## Test

```cmd
cd /d C:\BatchRecon
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

# Batch Reconciliation v5.2 — readable cards and unmatched diagnostics

This release builds on **v5.1 Completed Early** without changing its reconciliation rules or SQLite schema.

## What's new

- Card **bold title** uses `BatchMaster.commonname` (the **CommonName** field in the Master CSV). If this field contains the long OpCon name, edit it to the friendly display name; the app does not guess one.
- Frequency-colored square shows the **batch prefix** derived from `BatchName` / `jobid`: `BI-TFISS-MLY` -> `BI`, `IN-RSDXV-ONR` -> `IN`. When a CommonName card groups jobs with different prefixes, the square shows `MIX`.
- Card shows the batch code below the title and the full OpCon name as smaller secondary text; hover still displays all underlying jobs, status and runtime.
- After a daily import or a Batch Master change, a **read-only** unmatched diagnostic CSV is regenerated at `C:\BatchRecon\logs\unmatched_daily_matches.csv` by default (the path is relative to the extracted application directory, not hardcoded). Override with environment variable `UNMATCHED_LOG_PATH` if desired.
- Master View shows the current unmatched count and offers **Download unmatched CSV log** and **Regenerate diagnostics**. The download requires Master login.
- Log columns: `scheduled_date`, `source_file`, `source_row`, `daily_schedule`, `daily_opcon_full_batch_name`, `daily_status`, `reason`, `suggested_master_schedule`, `suggested_master_opcon_full_batch_name`, `suggested_batch_name`, `similarity_pct`, `master_effective_from`, `master_effective_to`.
- Reasons include `NEAR_NAME_MATCH`, `NAME_CASE_OR_SPACING`, `SCHEDULE_MISMATCH`, `AMBIGUOUS_SCHEDULE`, `NO_ACTIVE_MASTER_FOR_MONTH`, `POSSIBLE_MATCH_LOW_CONFIDENCE`, and `NO_CLOSE_MATCH`.
- Diagnostics include **all currently unmatched** imported daily runs; only sufficiently similar candidates are suggested for `NO_CLOSE_MATCH`. Suggestions are informational and **never** automatically update Batch Master or mark a batch completed. Matching remains exact and effective-month aware.

## Upgrade existing Windows v5.1 (recommended patch)

1. Stop Waitress (`Ctrl+C` or Windows Service) and pause the hourly `run_scan.bat` task.
2. Back up the **live** SQLite DB (the one pointed to by `BATCH_RECON_DB`) while both processes are stopped.
3. Extract the **v5.2 update patch** into `C:\BatchRecon`, overwriting files. Do **not** delete or replace the existing database.
4. Start `start_server.bat` again and resume the scheduled task.
5. Open **Master View** and click **Regenerate diagnostics** to audit already-imported daily records. Then download the log.
6. Refresh User View and check that cards show the friendly CommonName and `BI`/`IN` prefix.

No new Python dependencies, DB schema migration, or CSV column changes are required. The patch does not contain a database.

For unattended regeneration from an existing DB:

```cmd
cd /d C:\BatchRecon
.venv\Scripts\python.exe refresh_match_log.py
```

For pure-Python unit tests:

```cmd
cd /d C:\BatchRecon
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## Existing daily CSV schema

```csv
scheduled_date,schedulename,opcon_full_batch_name,runtime,status
2026-11-04,APP005,J05.01.BI-GPABU-MLY GPA BURIAL ISSUANCE STAGING,00:12:43,Completed
```

`scheduled_date`, `opcon_full_batch_name`, and `status` are required; `schedulename` and `runtime` are optional. The app does **not** use fuzzy matching to update the dashboard, so review near-match diagnostics and correct the source CSV or effective-dated Master manually when appropriate.

## v5.1 reconciliation behavior retained

A successful early run in W2 can satisfy its expected W3 slot as **Completed Early**, while also appearing as an **Early-run exception** in W2. Each execution is assigned to at most one expected week; exact-week runs take priority, and no matching crosses month boundaries.

## Security and deployment

Keep using Waitress for the Windows application server, Master authentication, CSRF, a protected internal subnet, and HTTPS through an approved reverse proxy when logging in over the network. Diagnostic logs contain batch metadata and should remain in a directory readable only by authorized operations staff. The log is CSV-formula-safe for spreadsheet viewing. Do not place it in a public static directory.

---

## Original v5.1 deployment and setup reference

# Monthly Batch Reconciliation — v5.1 (Option B: Completed Early)

This build keeps the database-driven monthly Batch Schedule UI and effective-dated batch master, and adds a security/production deployment layer for Windows.

## v5.1: early execution satisfies the expected week (Option B)

**Example:** Batch Master expects a monthly batch in **W3**, but the daily CSV
contains a `Completed` run on November 12 (**W2**).

- **W2** displays a separate **Early-run exception** (actual date, batch, expected W3).
- **W3** displays **Completed Early** for the expected card, with actual W2 date/runtime in its tooltip.
- The W3 pending count is **0**; the dashboard also reports **Early-run Exceptions**.
- The `DailyRun` database rows remain unchanged; reconciliation is calculated at display time.

**Matching/assignment rules:**

1. Only records from the selected calendar month are considered.
2. A daily run matches `schedulename + opcon_full_batch_name`. If schedule is
   omitted, the OpCon name must uniquely identify one active schedule.
3. Actual executions in an **expected** week take priority and cannot be
   borrowed to satisfy another expected week. This prevents a Weekly W2
   completion from also satisfying W3.
4. Only a **Completed** execution from an **earlier** week can satisfy an
   expected week that has **no same-week execution**. One actual run satisfies
   at most one expected week. When multiple eligible early runs exist, the
   latest unused completed run is selected for the earliest outstanding week.
5. A same-week Failed/Running execution remains Failed/Running, even if an
   earlier Completed execution exists; this preserves visibility of a later
   failure rather than masking it. Early Failed/Running runs do not satisfy
   an expected week. Late runs are **not** used to backfill earlier weeks.
6. Matching does **not** cross month boundaries. All weeks are the existing
   1–7, 8–14, 15–21, 22–month-end buckets based on `scheduled_date`.
7. If a Common Name groups several jobs, the card shows Completed Early when
   all jobs are completed and at least one completed early. Any failed,
   running or pending job retains the existing aggregate priority.

The dashboard's Early-run Exceptions count is the number of early executions
assigned to expected slots, **not** the number of distinct Common Name cards.

### Upgrade existing v5 installation (Windows)

1. Stop Waitress (`Ctrl+C` in its server window, or stop its Windows Service).
2. Pause the hourly `run_scan.bat` scheduled task while updating.
3. Back up the live SQLite database specified by `BATCH_RECON_DB` while no
   application/scanner process is using it.
4. Extract the **v5.1 update patch** into `C:\BatchRecon`, overwriting:
   `app.py`, `templates\user_month.html`, and adding `reconciliation.py`.
5. Restart `start_server.bat` or your Windows Service, then resume the scheduled task.
6. Refresh the browser. Open a month with an early Completed run and confirm
   the expected-week card shows Completed Early and the earlier week shows
   the exception.

**No CSV changes, dependency reinstall, schema migration or reimport are needed.**
The update package intentionally does not contain a SQLite database, so it
cannot overwrite your production data when extracted.

Run the self-contained reconciliation tests (does not require Flask):

```cmd
cd /d C:\BatchRecon
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## What changed from v3

- **User View remains read-only and does not require a login.**
- **Master View is authenticated.** Default username is `batchuser`; the password is never hard-coded in the application.
- All Master POST actions use **CSRF protection**.
- Master login has a basic failed-login throttle (5 attempts per client in 15 minutes).
- Master activity is written to an **AuditLog** table.
- Sessions are HTTP-only, SameSite=Lax, expire after 30 minutes, and can be marked Secure when HTTPS is used.
- Security headers are added to HTTP responses.
- Batch frequency values are allow-listed; arbitrary values are rejected.
- Daily CSV now requires `scheduled_date`, `opcon_full_batch_name`, and `status`. `runtime` and `schedulename` are optional but recommended.
- Uploads are limited to 10 MB and 50,000 rows by default.
- The dashboard no longer reinserts frequency values using `insertAdjacentHTML`; it uses DOM text nodes.
- SQLite initializes **WAL mode at application import/startup**, including when hosted under Waitress.
- Database writes use a cross-process lock plus a 60-second SQLite busy timeout.
- The in-process background polling thread is removed.
- Automatic CSV scanning is intended to run **hourly using Windows Task Scheduler** and `scan_daily.py`.
- `python app.py` is intentionally disabled for this production build.
- Production serving uses **Waitress** via `run_server.py`.

## Production components

Pinned dependencies:

```text
Flask==3.1.3
Waitress==3.0.2
```

Install:

```cmd
cd C:\BatchRecon
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Configure Master authentication

The default username is:

```text
batchuser
```

You can override it with `MASTER_USERNAME`.

### Recommended: password hash

Generate a password hash after dependencies are installed:

```cmd
.venv\Scripts\python.exe generate_password_hash.py
```

Copy the resulting hash and set it as a **machine-level protected environment variable** or through your approved service configuration:

```cmd
setx /M MASTER_USERNAME "batchuser"
setx /M MASTER_PASSWORD_HASH "<generated hash>"
```

Alternatively, `MASTER_PASSWORD` is supported, but a password hash is preferred because it avoids keeping the clear-text password in application configuration.

### Session signing secret

Generate a strong secret:

```cmd
.venv\Scripts\python.exe -c "import secrets; print(secrets.token_hex(32))"
```

Then configure:

```cmd
setx /M SECRET_KEY "<generated random value>"
```

Open a new Command Prompt / restart the service after changing machine environment variables.

## Database and input folders

Defaults:

```text
Database:   <app folder>\batch_recon_v2.db
Daily CSV:  <app folder>\daily_csv\
```

The default database filename intentionally remains `batch_recon_v2.db` so an existing v3 database can continue to be used after the app files are upgraded.

For a dedicated production location:

```cmd
setx /M BATCH_RECON_DB "C:\BatchRecon\data\batch_recon.db"
setx /M DAILY_CSV_DIR "C:\BatchRecon\daily_csv"
```

If moving from the current v3 database, stop all old Python/Waitress processes first and copy the database while no process is using it. Do not separately copy `-wal` / `-shm` files from a running database.

Keep the SQLite DB on a **local Windows disk**, not a network share, OneDrive, Dropbox, or synced folder.

## Start the production server

Set the interface and port if desired:

```cmd
setx /M HOST "10.20.30.40"
setx /M PORT "8080"
```

For localhost-only use behind Caddy/IIS/reverse proxy:

```cmd
setx /M HOST "127.0.0.1"
setx /M PORT "8080"
```

Then run:

```cmd
start_server.bat
```

or:

```cmd
.venv\Scripts\python.exe run_server.py
```

`run_server.py` serves the Flask application using Waitress. The Flask development server is not used.

## HTTPS

If the app is behind Caddy, IIS, F5, or another HTTPS reverse proxy, enable secure cookies:

```cmd
setx /M COOKIE_SECURE "1"
```

Only enable this when users really access the app over HTTPS; otherwise the browser will not send the Master session cookie.

For internal HTTP-only use approved by your security team, leave `COOKIE_SECURE=0` and restrict network access with Windows Firewall / network ACLs.

## Hourly automatic CSV import

The web app no longer runs an internal polling thread. Configure Windows Task Scheduler to run:

```text
C:\BatchRecon\run_scan.bat
```

once every hour.

Example command (run from an elevated Command Prompt and adjust the path/account for your environment):

```cmd
schtasks /Create /TN "BatchRecon Hourly CSV Scan" /SC HOURLY /MO 1 /TR "C:\BatchRecon\run_scan.bat" /F
```

For enterprise deployment, use an approved service/task account with only the required filesystem permissions.

The Master View still has an authenticated **Scan folder now** button for an immediate scan.

## CSV formats

### Daily run CSV

Required logical fields:

```csv
scheduled_date,opcon_full_batch_name,status
```

Recommended complete format:

```csv
scheduled_date,schedulename,opcon_full_batch_name,runtime,status
2026-11-04,APP005_BENEFIT_ISSUANCE,GPA Burial Issuance,BI-GPABU-MLY,Completed
```

Daily-run aliases include `rundate`/`run_date` for `scheduled_date`, `jobname` for `opcon_full_batch_name`, and `duration`/`elapsed_time` for `runtime`.

Recognized statuses include completed/success, failed/error, running/in progress, pending/waiting, and unknown/N/A equivalents. Unsupported statuses are rejected rather than silently treated as completed.

### Batch master CSV

```csv
ScheduleName,OpConFullBatchName,BatchName,CommonName,Frequency,Weeks
```

Allowed frequencies:

```text
Daily, Weekly, BiWeekly, Semi-Monthly, Monthly, Quarterly, Annual, ADHOC, 36Month
```

`Yearly` is normalized to `Annual`.

## Effective-dated changes

Batch additions, edits, and removals remain effective-dated. A change effective October does not rewrite September or earlier months. The old version is closed at the previous month and the new version starts at the requested effective month.

## Master security behavior

- `/master` redirects unauthenticated users to `/login`.
- Master add/edit/remove/import/scan routes require an authenticated Master session.
- Every modifying form includes a CSRF token.
- Logout is a POST action with CSRF validation.
- Master actions are written to `AuditLog` with username, action, client address, and timestamp.

## Recommended Windows permissions

The service/task account should have:

- Read/execute on application code.
- Modify access to the SQLite database directory.
- Read access to the inbound CSV directory (write only if your workflow requires it).
- Write access to an approved log directory if process logs are redirected there.

Ordinary users should not have direct filesystem access to the SQLite database.

## Limits

Defaults can be changed through environment variables:

```text
MAX_UPLOAD_MB=10
MAX_CSV_ROWS=50000
WAITRESS_THREADS=4
```

## Upgrade checklist from v3

1. Stop every old Flask/Waitress/Python instance using the app database.
2. Back up `batch_recon_v2.db`.
3. Replace application files with v5, or set `BATCH_RECON_DB` to the existing DB path.
4. Install the pinned dependencies.
5. Configure `SECRET_KEY` and `MASTER_PASSWORD_HASH` (or `MASTER_PASSWORD`).
6. Start `run_server.py` / `start_server.bat`.
7. Sign in to Master View as `batchuser` and verify existing batch data.
8. Configure Windows Task Scheduler to run `run_scan.bat` hourly.
9. Restrict the server port using Windows Firewall and use HTTPS if required by policy.
10. Remove/disable old v2/v3 scheduled jobs or server processes.
