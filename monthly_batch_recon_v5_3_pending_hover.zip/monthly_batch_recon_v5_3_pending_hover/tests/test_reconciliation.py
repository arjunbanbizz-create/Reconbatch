"""Run with: python -m unittest discover -s tests -v

No Flask installation is needed to test the reconciliation core.
"""
import ast
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from reconciliation import assign_expected_weeks, aggregate_card_status, week_of
from match_diagnostics import batch_prefix


def make_run(day, status='COMPLETED', id_=1):
    return {'id': id_, 'scheduled_date': f'2026-11-{day:02d}', 'loaded_at': '2026-11-04T00:00:00',
            'status': status, 'runtime': '00:12:43'}


class AssignmentTests(unittest.TestCase):
    def test_w3_completed_in_w2(self):
        assigned, exceptions = assign_expected_weeks([3], [make_run(12)])
        self.assertEqual(assigned[3]['status'], 'COMPLETED_EARLY')
        self.assertEqual((exceptions[0]['actual_week'], exceptions[0]['expected_week']), (2, 3))

    def test_w3_on_time(self):
        assigned, exceptions = assign_expected_weeks([3], [make_run(18)])
        self.assertEqual(assigned[3]['status'], 'COMPLETED')
        self.assertEqual(exceptions, [])

    def test_weekly_run_not_double_counted(self):
        assigned, exceptions = assign_expected_weeks([1, 2, 3, 4], [make_run(12)])
        self.assertEqual(assigned[2]['status'], 'COMPLETED')
        self.assertEqual(assigned[3]['status'], 'PENDING')
        self.assertEqual(exceptions, [])

    def test_one_early_run_only_satisfies_one_future_week(self):
        assigned, exceptions = assign_expected_weeks([3, 4], [make_run(12)])
        self.assertEqual(assigned[3]['status'], 'COMPLETED_EARLY')
        self.assertEqual(assigned[4]['status'], 'PENDING')
        self.assertEqual(len(exceptions), 1)

    def test_early_failed_run_not_satisfying(self):
        assigned, exceptions = assign_expected_weeks([3], [make_run(12, 'FAILED')])
        self.assertEqual(assigned[3]['status'], 'PENDING')
        self.assertFalse(exceptions)

    def test_failed_on_expected_week_not_masked_by_early(self):
        assigned, exceptions = assign_expected_weeks([3], [make_run(12, id_=1), make_run(18, 'FAILED', id_=2)])
        self.assertEqual(assigned[3]['status'], 'FAILED')
        self.assertFalse(exceptions)

    def test_late_run_does_not_backfill(self):
        assigned, exceptions = assign_expected_weeks([2], [make_run(18)])
        self.assertEqual(assigned[2]['status'], 'PENDING')
        self.assertFalse(exceptions)

    def test_aggregate_mixed_completed_early(self):
        self.assertEqual(aggregate_card_status(['COMPLETED', 'COMPLETED_EARLY']), 'COMPLETED_EARLY')
        self.assertEqual(aggregate_card_status(['PENDING', 'COMPLETED_EARLY']), 'PENDING')


class DashboardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Extract only pure SQL/dashboard functions; the installed Flask app
        # performs production initialization and is not needed for these tests.
        source = ast.parse((ROOT / 'app.py').read_text(encoding='utf-8'))
        names = {'build_dashboard', 'month_bounds', 'active_batch_rows', 'weeks_list', 'month_key'}
        selected = [n for n in source.body if isinstance(n, ast.FunctionDef) and n.name in names]
        module = ast.Module(body=selected, type_ignores=[])
        cls.functions = compile(ast.fix_missing_locations(module), str(ROOT / 'app.py'), 'exec')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.dbpath = Path(self.temp.name) / 'test.db'
        self.conn = sqlite3.connect(self.dbpath)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript('''
            CREATE TABLE BatchMaster (
                batch_key TEXT, schedulename TEXT, jobname TEXT, jobid TEXT,
                commonname TEXT, frequency TEXT, weeks TEXT,
                effective_from TEXT, effective_to TEXT
            );
            CREATE TABLE DailyRun (
                id INTEGER PRIMARY KEY, scheduled_date TEXT, schedulename TEXT,
                opcon_full_batch_name TEXT, runtime TEXT, status TEXT, loaded_at TEXT
            );
        ''')
        from reconciliation import assign_expected_weeks, aggregate_card_status, week_of
        from match_diagnostics import batch_prefix
        from datetime import date
        self.ns = {'date': date, 'assign_expected_weeks': assign_expected_weeks,
                   'aggregate_card_status': aggregate_card_status, 'week_of': week_of, 'batch_prefix': batch_prefix,
                   'get_db': self.get_db}
        exec(self.functions, self.ns)

    def tearDown(self):
        self.conn.close()
        self.temp.cleanup()

    def get_db(self):
        c = sqlite3.connect(self.dbpath)
        c.row_factory = sqlite3.Row
        return c

    def add_master(self, sched='APP005', opcon='OPCON_A', common='GPA Burial', weeks='3', key='batch1'):
        self.conn.execute('INSERT INTO BatchMaster VALUES(?,?,?,?,?,?,?,?,?)',
                          (key, sched, opcon, 'BI-MLY', common, 'Monthly', weeks, '2026-01', None))
        self.conn.commit()

    def add_run(self, day=12, sched='APP005', opcon='OPCON_A', status='COMPLETED', id_=1):
        self.conn.execute('INSERT INTO DailyRun VALUES(?,?,?,?,?,?,?)',
                          (id_, f'2026-11-{day:02d}', sched, opcon, '00:12:43', status, '2026-11-20T00:00:00'))
        self.conn.commit()

    def dashboard(self):
        return self.ns['build_dashboard'](2026, 11)

    def test_monthly_early_exception_in_actual_week(self):
        self.add_master()
        self.add_run()
        result = self.dashboard()
        sch = result['schedules'][0]
        self.assertEqual(sch['weeks'][3][0]['status'], 'COMPLETED_EARLY')
        self.assertEqual(sch['weeks'][3][0]['jobs'][0]['actual_week'], 2)
        self.assertEqual(sch['exceptions'][2][0]['expected_week'], 3)
        self.assertEqual(result['stats']['early_exceptions'], 1)
        self.assertEqual(result['stats']['pending'], 0)

    def test_exact_week_takes_priority(self):
        self.add_master()
        self.add_run(12, id_=1)
        self.add_run(18, id_=2)
        result = self.dashboard()
        self.assertEqual(result['schedules'][0]['weeks'][3][0]['status'], 'COMPLETED')
        self.assertEqual(result['stats']['early_exceptions'], 0)

    def test_wrong_schedule_cannot_match(self):
        self.add_master()
        self.add_run(sched='APP999')
        result = self.dashboard()
        self.assertEqual(result['stats']['pending'], 1)
        self.assertEqual(result['stats']['early_exceptions'], 0)

    def test_ambiguous_missing_schedule_cannot_match(self):
        self.add_master()
        self.add_master(sched='APP006', key='batch2')
        self.add_run(sched=None)
        result = self.dashboard()
        self.assertEqual(result['stats']['pending'], 2)
        self.assertEqual(result['stats']['early_exceptions'], 0)

    def test_unique_missing_schedule_can_match(self):
        self.add_master()
        self.add_run(sched=None)
        self.assertEqual(self.dashboard()['stats']['pending'], 0)

    def test_pending_hover_lists_are_consistent_with_counters(self):
        self.add_master(sched='APP005', opcon='OPCON_A', common='GPA Burial', weeks='1,3', key='a')
        self.add_master(sched='APP005', opcon='OPCON_B', common='SSP Staging', weeks='2', key='b')
        self.add_master(sched='APP006', opcon='OPCON_C', common='Other Batch', weeks='4', key='c')
        self.add_run(day=3, sched='APP005', opcon='OPCON_A', status='COMPLETED', id_=1)
        self.add_run(day=12, sched='APP005', opcon='OPCON_B', status='FAILED', id_=2)
        self.add_run(day=25, sched='APP006', opcon='OPCON_C', status='RUNNING', id_=3)
        result = self.dashboard()
        self.assertEqual(result['stats']['pending'], 3)
        self.assertEqual(len(result['pending_lists']['all']), 3)
        self.assertEqual(len(result['pending_lists']['schedules']['APP005']), 2)
        self.assertEqual(len(result['pending_lists']['schedules']['APP006']), 1)
        by_name = {x['commonname']: x for x in result['pending_lists']['all']}
        self.assertEqual((by_name['GPA Burial']['week'], by_name['GPA Burial']['status']), (3, 'PENDING'))
        self.assertEqual((by_name['SSP Staging']['week'], by_name['SSP Staging']['status']), (2, 'FAILED'))
        self.assertEqual(by_name['SSP Staging']['last_run'], '2026-11-12')
        self.assertEqual(by_name['Other Batch']['status'], 'RUNNING')
        for sch in result['schedules']:
            self.assertEqual(len(sch['pending_items']), sch['pending_total'])

    def test_completed_early_excluded_from_hover_list(self):
        self.add_master()
        self.add_run()
        result = self.dashboard()
        self.assertEqual(result['pending_lists']['all'], [])
        self.assertEqual(result['pending_lists']['schedules']['APP005'], [])

    def test_repeated_expected_weeks_get_separate_pending_entries(self):
        self.add_master(weeks='1,2,3,4')
        result = self.dashboard()
        self.assertEqual(result['stats']['pending'], 4)
        self.assertEqual([i['week'] for i in result['pending_lists']['all']], [1, 2, 3, 4])

    def test_effective_dated_master(self):
        self.add_master()
        self.conn.execute("UPDATE BatchMaster SET effective_from='2026-12'")
        self.conn.commit()
        self.add_run()
        self.assertEqual(self.dashboard()['stats']['jobs'], 0)


if __name__ == '__main__':
    unittest.main()
